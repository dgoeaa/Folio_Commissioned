import { Router } from './router.js';
import { State } from './state.js';
import { loadRuntimeData } from './data-loader.js';
import { PlatformProvisioner } from './platform-provisioner.js';
import { CacheManager } from './cache-manager.js';
import { LoadingState } from './loading-state.js';
import { PerformanceMonitor } from './performance-monitor.js';
import { PendingQueue } from './pending-queue.js';
import './nitda-module-adapter.js';
const modules = {'home':()=>import('../modules/home.js'),'ecm-erp-charter':()=>import('../modules/ecm-erp-charter.js'),'activities':()=>import('../modules/activities.js'),'correspondence':()=>import('../modules/correspondence.js'),'response-tracking':()=>import('../modules/response-tracking.js'),'orchestrator':()=>import('../modules/orchestrator.js'),'single-assignment':()=>import('../modules/single-assignment.js'),'bulk-assignment':()=>import('../modules/bulk-assignment.js'),'fasttrack':()=>import('../modules/fasttrack.js'),'approvals':()=>import('../modules/approvals.js'),'acknowledgment':()=>import('../modules/acknowledgment.js'),'dispatch':()=>import('../modules/dispatch.js'),'correspondence-email':()=>import('../modules/correspondence-email.js'),'scan-intake':()=>import('../modules/scan-intake.js'),'registry':()=>import('../modules/registry.js'),'briefs':()=>import('../modules/briefs.js'),'meetings':()=>import('../modules/meetings.js'),'projects':()=>import('../modules/projects.js'),'comments':()=>import('../modules/comments.js'),'reports':()=>import('../modules/reports.js'),'statistics':()=>import('../modules/statistics.js'),'executive':()=>import('../modules/executive.js'),'assistant':()=>import('../modules/assistant.js'),'lookup':()=>import('../modules/lookup.js'),'archive':()=>import('../modules/archive.js'),'admin-suite':()=>import('../modules/admin-suite.js'),'operator-hud':()=>import('../modules/operator-hud.js'),'settings':()=>import('../modules/settings.js'),'endpoint-console':()=>import('../modules/endpoint-console.js'),'diagnostics':()=>import('../modules/diagnostics.js'),'user-admin':()=>import('../modules/user-admin.js')};
/* H-02 — the icon sprite is fetched once and parked in the document so every <use href="#i-…">
   in the shell and in modules resolves. Fetched rather than inlined so the same file serves
   both packages and neither can drift from the other. A failure leaves the icons blank
   rather than stopping the platform: an icon is not worth a boot failure. */
async function installIconSprite(){
  if (document.getElementById('dgo-icon-sprite')) return;
  try{
    const res = await fetch(new URL('../assets/icons/sprite.svg', import.meta.url));
    if(!res.ok) return;
    const holder = document.createElement('div');
    holder.id = 'dgo-icon-sprite';
    holder.setAttribute('aria-hidden','true');
    holder.style.cssText = 'position:absolute;width:0;height:0;overflow:hidden';
    holder.innerHTML = await res.text();
    document.body.insertBefore(holder, document.body.firstChild);
  }catch{ /* icons degrade to empty; the platform does not */ }
}

async function boot(){
  const host=document.getElementById('app');
  try{
    await installIconSprite();
    PlatformProvisioner.ensure();
    window.__DGO_PROVISIONING__ = PlatformProvisioner.validate();
    // Identity. Inert posture registers nothing and behaves exactly as before. Enforced
    // posture installs the OTP provider, because with no identity provider configured it
    // is the only way to acquire a proof — and without one core/auth.js would throw
    // "no token provider is registered" on the first governed action. Imported lazily so
    // the inert path does not pay for a module it never uses.
    const { isAuthEnforced } = await import('../config/auth.config.js');
    if (isAuthEnforced()) {
      const { installOtpProvider, setSignInPrompt, watchOtherTabs } = await import('./otp-identity.js');
      installOtpProvider();
      /* One sign-in for the browser: a sign-in or sign-out in another tab reaches this one (dgo:signed-in, dgo:signed-out). */
      watchOtherTabs(window);
      /* DL-1: an action that needs identity asks for it here and then carries on, so a link
         opened while signed out still lands on its task once the person has signed in. */
      setSignInPrompt(async () => (await import('../shared/sign-in-dialog.js')).promptSignIn());
      /* Sign in (or pick up the proof this browser session already holds) BEFORE anything is
         drawn. Drawn first, every screen resolved an unknown user and showed "Access denied",
         and nothing redrew it after sign-in. The address bar is untouched until the deep link
         is read below, so a link opened while signed out still lands on its task. Cancelling
         leaves the Workspace to draw as an unauthenticated visitor, which it refuses cleanly. */
      const { getAccessToken } = await import('./auth.js');
      /* The boot watchdog in index.html pauses while this waits on the person (fetching a code
         from e-mail takes longer than its 15 seconds) and restarts its window once they are done. */
      window.__DGO_SIGNING_IN__ = true;
      try { await getAccessToken(); } catch (e) { console.warn('[DGO AUTH]', e?.message || e); }
      finally { window.__DGO_SIGNING_IN__ = false; window.__DGO_SIGNED_IN_AT__ = Date.now(); }
    }
    window.__DGO_DATA_OPS__ = { cache:CacheManager, loading:LoadingState, performance:PerformanceMonitor, pending:PendingQueue };
    for(const [id,load] of Object.entries(modules)) Router.register(id, async el => (await load()).mount(el));
    const s=State.get(); document.documentElement.dataset.theme=s.settings.theme; document.documentElement.dataset.density=s.settings.density; /* The welcome experience's sign-in is a demonstration: it accepts any code. Once auth is enforced the real sign-in (shared/sign-in-dialog.js) is the only one, so the demo is not shown. */ if(!isAuthEnforced()){ const wel=await import('./welcome-experience.js'); /* It waits on the person, as the sign-in does, so the boot watchdog in index.html waits too (it showed "could not start" over the welcome after 15 s). */ window.__DGO_SIGNING_IN__=true; try{ await wel.WelcomeExperience.run(); } finally { window.__DGO_SIGNING_IN__=false; window.__DGO_SIGNED_IN_AT__=Date.now(); } }
    await import('../shared/shell.js'); const rel=await import('../shared/relationship-runtime.js'); const welcome=await import('../shared/welcome-runtime.js'); rel.installRelationshipInterceptors(document); host.replaceChildren(document.createElement('dgo-shell')); const dl=await import('./deeplink-resolver.js'); const oq=await import('./offline-action-queue.js'); oq.OfflineActionQueue.installOnlineRetry(); requestAnimationFrame(()=>{ dl.DeepLinkResolver.resolveInitial(); /* A person who opened a link came for that task or item: the welcome tour would cover it, so it waits for their next visit. */ if(!dl.DeepLinkResolver.parse()?.route) welcome.launchWelcome(); }); window.__DGO_BOOTED__=true; loadRuntimeData().catch(e=>{ const message=String(e?.message||e||''); console.warn('[DGO DATA]', message); const s=State.get(); State.patch({runtime:{...s.runtime,lastLoad:{ok:false,offline:true,at:new Date().toISOString(),message},lastWarnings:[...(s.runtime?.lastWarnings||[]),message].slice(-10)}},{module:'boot',action:'data-load-deferred',event:'audit:data-load-deferred'}); });
  }catch(e){ console.error('[DGO BOOT]',e);
    // Escape before display. core/router.js already does this for the equivalent value;
    // boot did not, leaving an unescaped path into innerHTML for any error whose message
    // embeds caller-influenced text.
    const safe=String(e.stack||e).replace(/[&<>]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[m]));
    host.innerHTML=`<div class="fatal"><h1>DGO could not start</h1><pre>${safe}</pre></div>`; }
}
// Only auto-boot in a browser; keeps the entrypoint importable in non-browser diagnostic contexts.
if (typeof document !== 'undefined' && typeof window !== 'undefined') boot();
